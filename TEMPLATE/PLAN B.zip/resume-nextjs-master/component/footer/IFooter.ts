export declare namespace IFooter {
  export interface Payload {
    github: string;
    version: string;
    nextVersion: string;
    reactVersion: string;
    bootstrapVersion: string;
  }
}
